// export interface User{
//       name1:string
// }

export  class User{
    constructor(
       public FirstName:string,
       public LastName:string,
       public Email:string,
       public ContactNo:string



    ){}
}