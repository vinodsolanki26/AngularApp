export interface Hoteldata
{
    hotel_id:number,
    country_id:string,
    state_id:number,
    city_id:number,
    location_id:number,
    facility_id:number,
    location_name:string,
    hotel_name:string,
    image_name:string,
    price:number,
    facility:string,
    city_name:string,
    rent_id:number
}

