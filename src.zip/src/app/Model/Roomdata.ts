export interface Roomdata
{
    room_type_id:number,
    description:string,
    max_capacity:string
}