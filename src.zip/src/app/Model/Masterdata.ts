export interface Masterdata
{
    country_id:number,
    country_name:string,
    state_id:number,
    state_name:string,
    city_id:number,
    city_name:string,
    location_id:number,
    location_name:string
}